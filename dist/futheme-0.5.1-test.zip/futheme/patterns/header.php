<?php
/**
 * Title: Header: standard
 * Slug: futheme/header
 * Categories: header
 * Block Types: core/template-part/header
 * Description: Logo and site title on the left, menu on the right.
 *
 * @package futheme
 */

?>
<!-- wp:group {"tagName":"header","align":"full","className":"fu-site-header","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}},"border":{"top":{"color":"var:preset|color|primary","width":"4px"}}},"backgroundColor":"base","layout":{"type":"constrained"}} -->
<header class="wp-block-group alignfull fu-site-header has-base-background-color has-background" style="border-top-color:var(--wp--preset--color--primary);border-top-width:4px;padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:site-logo {"width":44} /-->

<!-- wp:site-title {"level":0} /--></div>
<!-- /wp:group -->

<!-- wp:navigation {"overlayBackgroundColor":"base","overlayTextColor":"contrast","style":{"typography":{"fontWeight":"500"}},"layout":{"type":"flex","justifyContent":"right","flexWrap":"wrap"}} /--></div>
<!-- /wp:group --></header>
<!-- /wp:group -->
